package br.com.matrix.matrix;

public class testeMe {

	public static void main(String[] args) {
		System.out.println((new EstruturaMatrix(1).toString()));
	}

}
