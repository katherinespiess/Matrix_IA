package br.com.matrix.matrix;

public class SugestaoMatrix {
	Sugestor s;

	public Sugestor getSugestor() {
		return s;
	}
}
