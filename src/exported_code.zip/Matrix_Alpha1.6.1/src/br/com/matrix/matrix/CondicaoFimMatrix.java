/**
 * 
 */
package br.com.matrix.matrix;

import java.util.HashMap;

import br.com.matrix.evo.suporte.CondicaoFimEvo;

/**
 * @author GustavoHenrique
 *
 */
public class CondicaoFimMatrix implements CondicaoFimEvo<HashMap<String, Object>> {

    @Override
    public boolean test(HashMap<String, Object> t) {
	// TODO Auto-generated method stub
	return false;
    }

}
