package br.com.matrix.evo.suporte;

import java.util.ArrayList;

/**
 * ArrayList de Alelos gen�tcos.
 * 
 * @param <G>
 *            - Tipagem do c�digo gen�tico
 */
public class CodigoGenEvo<G> extends ArrayList<G> {

    private static final long serialVersionUID = 1077258367168846110L;
}
