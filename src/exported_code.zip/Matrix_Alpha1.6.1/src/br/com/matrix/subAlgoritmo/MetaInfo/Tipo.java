package br.com.matrix.subAlgoritmo.MetaInfo;

public interface Tipo {
    public String get();
}
