package br.com.matrix.subAlgoritmo.MetaInfo;

public interface MetaInfoAssinatura extends MetaInfo {
    public Qt getQt();    
}
