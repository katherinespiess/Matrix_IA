package br.com.matrix.subAlgoritmo.MetaInfo;

import java.util.List;

public interface MetaInfoExec extends MetaInfo{
    public List<MetaInfoAssinatura> getParam();
}
